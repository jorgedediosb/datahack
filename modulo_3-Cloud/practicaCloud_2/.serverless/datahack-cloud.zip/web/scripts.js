var API_ENDPOINT = "https://gg897qwhoe.execute-api.eu-west-1.amazonaws.com/dev";
//var API_ENDPOINT = "https://${HttpApi}.execute-api.eu-west-1.amazonaws.com/dev";
//var API_ENDPOINT = "https://z6pgz8tnag.execute-api.eu-west-1.amazonaws.com/Prod/";
//var API_ENDPOINT = "https://datahack-cloud.s3.eu-west-1.amazonaws.com/index.html";
//var API_ENDPOINT = "https://${HttpApi}.execute-api.${AWS::Region}.${AWS::URLSuffix}/${self:provider.stage}/";
//var API_ENDPOINT = "https://${provider.apiGateway.restApiId}.execute-api.${provider.region}.amazonaws.com/${provider.stage}"
//var API_ENDPOINT = "https://${restApiId}.execute-api.${provider.region}.amazonaws.com/${provider.stage}"
//var API_ENDPOINT = "https://${ApiEndpoint}.execute-api.${AWS::Region}.amazonaws.com/${self:provider.stage}"
//var API_ENDPOINT = "https://${ApiGatewayRestApi}"
//var API_ENDPOINT = "https://${ApiEndpoint}.execute-api.${AWS::Region}.amazonaws.com/${self:provider.stage}"
//var API_ENDPOINT = "https://${API_ENDPOINT}";
// var API_ENDPOINT = "https://${ApiGatewayRestApi}.execute-api.${AWS::Region}.${AWS::URLSuffix}/${self:provider.stage}";
//var API_ENDPOINT = "https://{restapi-id}.execute-api.{region}.amazonaws.com/{stageName}";
//var API_ENDPOINT = "<%= process.env.API_ENDPOINT %>";

//AJAX POST REQUEST
document.getElementById("savemessage").onclick = function(){
  var currentDate = new Date();
  var formattedDate = currentDate.toLocaleString('es-ES', { month: 'long', day: 'numeric', year: 'numeric' });
  var inputData = {
    "user": $('#user').val(),
    "message": $('#msg').val(),
    "date": formattedDate
  };
  $.ajax({
    url: API_ENDPOINT + "/insert-message",
    type: 'POST',
    data: JSON.stringify(inputData),
    contentType: 'application/json; charset=utf-8',
    success: function (response) {
      document.getElementById("messageSaved").innerHTML = "Mensaje enviado!";
      $('#user').val('');
      $('#msg').val('');
    },
    error: function () {
      alert("Error al enviar el mensaje!");
    }
  });
}

//AJAX GET REQUEST 
document.getElementById("getmessages").onclick = function(){  
  $.ajax({
    url: API_ENDPOINT + "/get-messages",
    type: 'GET',
    contentType: 'application/json; charset=utf-8',
    success: function (response) {
      $("#showMessages").empty();
      jQuery.each(response, function (i, data) {
        var messageCardHtml = '<div class="messageCard">' +
          '<div class="messageContent">' + data["msg"] + '</div>' +
          '<div class="messageDetail">From: ' + data["user"] + ' ' + ' el ' + data["date"] + '</div>' +
          '</div>';
        $("#showMessages").append(messageCardHtml);
      });
    },
    error: function () {
      alert("Error. No pueden visualizarse los mensajes.");
    }
  });
}
