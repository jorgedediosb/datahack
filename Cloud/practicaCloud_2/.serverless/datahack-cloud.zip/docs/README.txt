INSTRUCCIONES PARA DESPLEGAR APP ANUNCIOS Y MENSAJERÍA EN AWS
  Instalar AWS CLI:
    pip install awscli --upgrade --user
    aws --version (confirmar versión)

  Instalar serverless en la carpeta donde se aloje el proyecto:
    npm install serverless

  Instalar plugin Serverless S3 Sync:
    npm install --save serverless-s3-sync

  Instalar plugin Serverless Finch:
    npm install --save serverless-finch

  Configurar AWS CLI con credenciales de AWS:
    aws configure
    > introducir: Access Key y Secret Key del usuario AWS

  Desplegar la app:
    sls deploy
    sls client deploy (plugin finch para frontend)
    > confirmar cambios con 'y' si los hay.
  
  Información sobre el despliegue:
      sls info

  Eliminar despliegue:
    sls remove

Finalizado el despliegue indicará los endpoints y las funciones:
  endpoints (el ID varía según el usuario):
    POST - https://gg897qwhoe.execute-api.eu-west-1.amazonaws.com/dev/insert-message
    GET - https://gg897qwhoe.execute-api.eu-west-1.amazonaws.com/dev/get-messages
    POST - https://gg897qwhoe.execute-api.eu-west-1.amazonaws.com/dev/insert-product
    GET - https://gg897qwhoe.execute-api.eu-west-1.amazonaws.com/dev/get-products
  functions:
    insertMessage: datahack-cloud-dev-insertMessage
    getMessages: datahack-cloud-dev-getMessages
    insertProduct: datahack-cloud-dev-insertProduct
    getProduct: datahack-cloud-dev-getProduct
  
FUNCIONES
  Enviar mensajes:
    curl -X POST -H "Content-Type: application/json" -d '{"user":"Jorge", "message":"hola mundo!"}' https://gg897qwhoe.execute-api.eu-west-1.amazonaws.com/dev/insert-message
  Leer mensajes:
    curl https://gg897qwhoe.execute-api.eu-west-1.amazonaws.com/dev/get-messages

  Enviar productos:
    curl -X POST -H "Content-Type: application/json" -d '{"user":"Jorge", "product":"Iphone", "description": "Iphone muy guapo"}' https://gg897qwhoe.execute-api.eu-west-1.amazonaws.com/dev/insert-product
  Leer productos:
    curl https://gg897qwhoe.execute-api.eu-west-1.amazonaws.com/dev/get-products

ACCESO INTERFAZ WEB:
  Acceder a las ditribuciones activas:
    al ejecurar 'sls client deploy' devuelve:
    Success! Your site should be available at http://datahack-cloud.s3-website-eu-west-1.amazonaws.com/

    aws cloudfront list-distributions
    > abrir en navegador el DomainName (similar a d1parznpwmoz4t.cloudfront.net) del Item con descripción: 'Datahack Cloud'

  Cargar archivos directorio 'web' en el bucket:
    aws s3 cp web/ s3://datahack-cloud/ --recursive
    curl https://datahack-cloud.s3-eu-west-1.amazonaws.com/index.html o visitar enlace en navegador

  > La interfaz web sólo  tiene las funciones de enviar mensajes y leer mensajes ya que no he logrado que se capture la url de la API (en consola SI funcionan)
  > Pude 'cargar' manualmente en proyecto en AWS con los mismos servicios y  el funcionamiento es perfecto.
  > Enlace interfaz cargada en AWS manualmente: https://d1671x27qva124.cloudfront.net

CONTENIDO EXTRA
  - Incluyo diagama de arquitectura en AWS.
  - Incluyo carpeta 'web-prueba-anuncios' con interfaz web de publicación de anuncios y mensajería que funciona en local.
    NO LOGRÉ EL CORRECTO FUNCIONAMIENTO DE ESTA INTERFAZ AL DESPLEGAR, en local sí funciona.
    Creo que  necesita una relación entre tablas anuncios/mensajes que no logré desplegar correctamente.

EXPLICACIÓN DE SERVICIOS ELEGIDOS
He querido crear un servicio web lo más real posible usando los servicios aprendidos y más típicos para este proyecto:
  - Cloudfront para el acceso desde cualquier sitio.
  - IAM para los roles de acceso.
  - S3 para el alojamiento web.
  - API Gateway para las peticiones a las funciones.
  - Lambda para cada una de las funciones.
  - DynamoDB para alojar las tablas de mensajes y anuncios por separado.

Un proyecto real tendría como mínimo, a parte de los servicio usados:
  Amazon Cognito para la autenticación de usuarios y el control de acceso.
  Amazon Simple Notification Service (SNS) para notificaciones en tiempo real.
  AWS Amplify: Para crear y hospedar la interfaz web estática (S3 para las imágenes).